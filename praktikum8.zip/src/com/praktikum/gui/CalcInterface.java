package com.praktikum.gui;

import javax.swing.*;

public interface CalcInterface {
    public void hasilCalc(JButton btn);
}
