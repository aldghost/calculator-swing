package com.praktikum.gui;

import javax.swing.*;

public class Praktikum8_1402019011 {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            MainFrame main = new MainFrame();
            main.setVisible(true);
        });
    }
}
